package Classes;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rodri
 */
public class Constantes {
    public static final double T1 = 1.1, T2 = 1.2, D1 = 1.05, D2 = 1.1, D3 = 1.2, S1 = 1.05, S2 = 1.1;
    public static final String ASSESSOR = "Assessor", LABORATORIO = "Laboratório", SECRETARIO = "Secretário";
    public static final double SALARIOBASE = 5000;
    public static final int MAX = 50;
    public static final String nT1 = "T1", nT2 = "T2", nD1 = "D1", nD2 = "D2", nD3 = "D3", nS1 = "S1", nS2 = "S2";
}
